package com.capgemini.bank.dao;

import java.util.Set;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;

public interface BankDao {

	long getBalance(long accountNo, String password);

	public long deposit(long accountNo, long depositedAmount);

	long withdrawl(long accountNo, long amountWithdrawl, String password) throws BankException;

	boolean transferMoney(long sourceAcNo, long destAcNo, long amount, String password) throws BankException;

	long saveAccount(Account acc);

	Set<Transaction> printTransaction() throws BankException; 
	public Account checkaccountNo(long accountNo) throws BankException;
	
	 // public void addAccount(long accountNo, Account account); boolean
	//  addTransaction(Transaction transaction) throws BankException; public
	  
	  
	 

}
