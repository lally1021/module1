package com.capgemini.bank.dao;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;

public class BankDaoImpl implements BankDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = emf.createEntityManager();
	TypedQuery<Account> tq;
	long accBal;

	
	  
	  @Override public long saveAccount(Account acc) {
	  em.getTransaction().begin();
	  em.persist(acc);
	  em.getTransaction().commit();
	  return acc.getAccountNo();
	  }
	 
	@Override
	public boolean transferMoney(long sourceAcNo, long destAcNo, long amount, String password)
			throws BankException {

		tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo and acc.password= :p",
				Account.class);
		tq.setParameter("acNo", sourceAcNo);
		tq.setParameter("p", password);

		accBal = tq.getSingleResult().getBalance();
		if (accBal >= amount) {
			em.getTransaction().begin();
			tq = em.createQuery("update Account acc set acc.accountBalance = :amt where acc.accountNo= :acNo",
					Account.class);
			tq.setParameter("amt", accBal - amount);
			tq.setParameter("acNo", sourceAcNo);

			int i = tq.executeUpdate();

			em.getTransaction().commit();
			if (i > 0)
				return true;
			else
				return false;
		} else
			throw new BankException("Insufficient Balance");
	}

	@Override
	public long deposit(long accountNo, long depositedAmount) {
		em.getTransaction().begin();
		tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo", Account.class);
		tq.setParameter("acNo", accountNo);

		accBal = tq.getSingleResult().getBalance();

		tq = em.createQuery("update Account acc set acc.accountBalance = :amt where acc.accountNo= :acNo",
				Account.class);
		tq.setParameter("amt", accBal + depositedAmount);
		tq.setParameter("acNo", accountNo);

		int i = tq.executeUpdate();

		em.getTransaction().commit();
		if (i > 0)
			return accBal + depositedAmount;
		return -1;
	}

	@Override
	public long getBalance(long accountNo, String password) {
		em.getTransaction().begin();
		tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo and acc.password= :p",
				Account.class);
		tq.setParameter("acNo", accountNo);
		tq.setParameter("p", password);
		Account a = tq.getSingleResult();
		em.getTransaction().commit();
		if (a != null)
			return a.getBalance();
		return -1;
	}

	@Override
	public long withdrawl(long accountNo, long amountWithdrawl, String password) throws BankException {
		tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo and acc.password= :p",
				Account.class);
		tq.setParameter("acNo", accountNo);
		tq.setParameter("p", password);

		accBal = tq.getSingleResult().getBalance();
		if (accBal >= amountWithdrawl) {
			em.getTransaction().begin();
			tq = em.createQuery("update Account acc set acc.accountBalance = :amt where acc.accountNo= :acNo",
					Account.class);
			tq.setParameter("amt", accBal - amountWithdrawl);
			tq.setParameter("acNo", accountNo);

			int i = tq.executeUpdate();

			em.getTransaction().commit();
			if (i > 0)
				return accBal - amountWithdrawl;
			else
				return -1;
		} else
			throw new BankException("Insufficient Balance");
	}

	@Override
	public Account checkaccountNo(long accountNo) throws BankException {
		Account acc1=null;
		 Query acc =  em.createQuery("from Account acc where accountNo=?",Account.class);
		 acc.setParameter(1, accountNo);
		 acc1=(Account) acc.getSingleResult();
		 return acc1;
	  
	}

	@Override
	public Set<Transaction> printTransaction() throws BankException {
		// TODO Auto-generated method stub
		return null;
	}
}
