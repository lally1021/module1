package com.capgemini.bank.exception;

public class BankException extends Exception{

	public BankException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
