package com.capgemini.bank.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.BankService;
import com.capgemini.bank.service.BankServiceImpl;

public class Main {
	public static void main(String[] args) {

		String continueChoice;
		boolean continueValue = false;
		BankService service = new BankServiceImpl();

		Scanner scanner = null;
		do {
			System.out.println(
					"Enter your choice\n1.Create Account\n2.Login\n3.Deposit\n4.Show Balance\n5.Withdraw\n6.Fund Transfer");
			int choice = 0;
			boolean choiceFlag = false;
			do {

				System.out.println("Enter input:");

				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;
					boolean flag = false;
					boolean checkAccount = false;

					String name;
					String mobileNo = null;
					String aadharNo;
					long balance;
					String password1 = null;
					long accountNo = 0;
					long accountBalance;

					String acNo;

					long amount = 0;
					String password;
					switch (choice) {
					case 1: {
						String firstName = "";
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter firstName:");
							firstName = scanner.next();
							try {
								service.validateName(firstName);
								flag = true;
							} catch (Exception e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						String lastName = "";
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Last Name:");
							lastName = scanner.next();
							try {
								service.validateName(lastName);
								flag = true;
							} catch (Exception e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							name = firstName.concat(lastName);
							try {
								service.validateName(name);
								flag = true;
							} catch (Exception e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);
						String senderMobile = "";
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile number:");
							senderMobile = scanner.next();
							try {
								service.validateMobileNumber(senderMobile);
								flag = true;
							} catch (BankException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);
//						System.out.println(name);
						String aadharNumber = "";

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Aadhar Number");
							aadharNo = scanner.next();
							try {
								service.validateAadharNumber(aadharNo);
								flag = true;
							} catch (Exception e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						String Password = "";
						do {
							scanner = new Scanner(System.in);
							System.out.println("Set password");
							password1 = scanner.next();
							try {
								service.validatePassword(password1);
								flag = true;
							} catch (Exception e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							balance = scanner.nextLong();
							try {
								service.validateAmount(balance);
								flag = true;
							} catch (BankException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						Account acc = new Account(0, balance, name, aadharNo, mobileNo, password1);
						long number = service.createAccount(accountNo, acc);
						System.out.println("Account number is " + number);

					}
						break;

					case 2: {

						System.out.println("Enter Account Number");
						acNo = scanner.next();
						try {
							Account acnt = service.validateAccountNumber(accountNo);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println("Enter password");
						password1 = scanner.next();
						if (service.validatePassword(password1)) {
							accountBalance = service.showBalance(accountNo, password1);
							if (accountBalance >= 0)
								System.out.println("Account Balance :" + accountBalance);
							else
								System.out.println("Please Try Again.....");
						}

						break;

					}

					case 3: {
						System.out.println("Enter Account Number");
						acNo = scanner.next();

						System.out.println("Enter Amount to Deposit");
						long damount = scanner.nextLong();
						accountBalance = service.deposit(accountNo, amount);
						if (accountBalance >= 0) {
							System.out.println("Amount Deposited Successfully");
							System.out.println("Account Balance:" + accountBalance);
						} else {
							System.out.println("Given Account Number Does Not Exist");
							System.out.println("Please Try Again.....");
						}

						break;
					}
					case 4: {
						System.out.println("Enter Account Number");
						acNo = scanner.next();
						System.out.println("Enter Pin");
						password = scanner.next();
						if (service.validatePassword(password)) {
							System.out.println("Enter Amount to withdraw");
							long wamount = scanner.nextLong();
							try {
								accountBalance = service.withdraw(accountNo, password, amount);
								if (accountBalance >= 0) {
									System.out.println("Amount withdrawn Successfully");
									System.out.println("Account  Balance :" + accountBalance);
								} else {
									System.out.println("Withdraw Failed");
									System.out.println("Please Try Again.....");
								}
							} catch (BankException e) {
								System.err.println("You have Insufficient Account Balance");
								e.printStackTrace();

							}

						}
						break;
					}
					/*
					 * case 5:System.out.println("Enter Source Account Number"); String
					 * sacNo=sc.next();
					 * 
					 * System.out.println("Enter pin"); pin=sc.next();
					 * if(service.validatePassword(password)) {
					 * System.out.println("Enter Destination Account Number"); String
					 * dacNo=sc.next(); System.out.println("Enter amount to transfer"); long
					 * tamount=sc.nextLong(); boolean transfered; try {
					 * 
					 * transfered = service.fundTransfer(sourceAcNo, destAcNo, amount, password);
					 * if(transfered) System.out.println("Amount Transfered Successfully"); else {
					 * System.out.println("Amount Transfered Failed");
					 * System.out.println("Please Try Again....."); } } catch (BankException e) {
					 * System.err.println("You have Insufficient Account Balance");
					 * e.printStackTrace(); } }
					 * 
					 * break;
					 */
					default:

						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;

					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}

			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}

}
