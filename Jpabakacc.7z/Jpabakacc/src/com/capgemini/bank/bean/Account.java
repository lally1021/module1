package com.capgemini.bank.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Account {
	@Id
	@SequenceGenerator(name = "myseq", sequenceName="aseq",allocationSize = 1)
    @GeneratedValue(strategy =GenerationType.SEQUENCE,generator = "myseq")
	private long accountNo;
	private long balance;
	private String name;
	private String aadharNo;
	private String mobileNo;
	private String password;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNo, long balance, String name, String aadharNo, String mobileNo, String password) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.name = name;
		this.aadharNo = aadharNo;
		this.mobileNo = mobileNo;
		this.password = password;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", balance=" + balance + ", name=" + name + ", aadharNo=" + aadharNo
				+ ", mobileNo=" + mobileNo + ", password=" + password + "]";
	}
	
}
