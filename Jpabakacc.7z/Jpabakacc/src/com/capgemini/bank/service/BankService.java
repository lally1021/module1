package com.capgemini.bank.service;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.exception.BankException;

public interface BankService {
 
	public long createAccount(long accountNo,Account account);
	public long showBalance(long accountNo,String password);
	public  long deposit(long accountNo,long amount);
	public  long withdraw(long accountNo,String password,long amount) throws BankException;
	public  boolean fundTransfer(long sourceAcNo,long destAcNo,long amount,String password) throws BankException;
	 // public boolean validateAccountNumber(long accNo);
	public boolean validateName(String name) throws BankException;
	public  boolean validateMobileNumber(String mobileNo) throws BankException;
	public  boolean validateAadharNumber(String aadharNo);
	public  boolean validatePassword(String password);
	//public Account validateAccountNumber(long accountNo)throws BankException;
	public boolean validateAmount(long balance) throws BankException;
	Account validateAccountNumber(long accountNo) throws BankException;
}
