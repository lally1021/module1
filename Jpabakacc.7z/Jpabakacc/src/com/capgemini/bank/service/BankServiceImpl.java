package com.capgemini.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.dao.BankDao;
import com.capgemini.bank.dao.BankDaoImpl;
import com.capgemini.bank.exception.BankException;

public class BankServiceImpl implements BankService {

	BankDao dao=new BankDaoImpl();
	
	@Override
	public long createAccount(long accountNo,Account account) {
		Account acc=new Account();
				return dao.saveAccount(acc);
	}
	
	@Override
	public long showBalance(long accountNo, String password) {
		return dao.getBalance(accountNo, password);
	}

	@Override
	public long deposit(long accountNo, long depositedAmount) {
		
		return dao.deposit(accountNo, depositedAmount);
	}

	@Override
	public long withdraw(long accountNo, String password,long amountWithdrawl) throws BankException {
	 
		return dao.withdrawl(accountNo, amountWithdrawl, password);
	}

	@Override
	public boolean fundTransfer(long sourceAcNo, long destAcNo, long amount,String password) throws BankException {
		return dao.transferMoney(sourceAcNo, destAcNo, amount, password);
	}

	
	
	
	  @Override 
	  public Account validateAccountNumber(long accountNo) throws BankException{ 
		  return dao.checkaccountNo(accountNo);
			    
			}
	 
	
	@Override
	public boolean validatePassword(String password)
	{
		if(password.matches("[A-Z][a-z][0-9]{4}"))
			return true;
		System.err.println("Please Enter Valid Pin");
		return false;
	}
	@Override
    public boolean validateName(String name) throws BankException
    {
	 boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
    }
	@Override
    public boolean validateMobileNumber(String mobileNo) throws BankException
    {
//		boolean resultFlag = false;
//		String mobile = String.valueOf(mobileNo);
//		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
//		Matcher match = nameptn.matcher(mobile);
//				if (match.matches()) {
//					System.out.println("anga");
//			resultFlag=true;
//			
//
//		}
//		else {
//			System.out.println("bhavya");
//			throw new BankException("first letter should be between 7-9 and the length should be 10");
//		}
//		return false;
		boolean resultFlag = false;
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new BankException("first letter should be between 7-9 and the length should be 10");
		}
		return false;
    }
	@Override
    public boolean validateAadharNumber(String aadharNo)
    {
    	if(aadharNo.matches("[0-9]{12}"))
    		return true;
    	System.err.println("Please Enter Valid Aadhar Number");
    	return false;
    }


	@Override
	public boolean validateAmount(long balance) throws BankException {

		boolean amountFlag = false;

		if (balance < 500) {
			throw new BankException("balance should not be lt 500");
		} else {
			amountFlag = true;
		}
		return amountFlag;
	
		
	}
}
