package com.capgemini.javaparallelproject.dao;

import java.util.Set;

import com.capgemini.javaparallelproject.bean.Account;
import com.capgemini.javaparallelproject.bean.Transaction;
import com.capgemini.javaparallelproject.exception.BankException;

public interface AccountDao {

	public long deposit(long accountNumber, long depositedAmount);

	public long getBalance(long accountNo);

	public void addAccount(long accountNo, Account account);

	public long withdrawl(long accountNo, long amountWithdrawl);

	//public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount);

	boolean addTraansaction(Transaction transaction) throws BankException;

	public Set<Transaction> printTransaction() throws BankException;
	public Account checkaccountNo(long accountNo) throws BankException;
}
