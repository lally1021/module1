package com.capgemini.javaparallelproject.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.javaparallelproject.bean.Account;
import com.capgemini.javaparallelproject.bean.Transaction;
import com.capgemini.javaparallelproject.dao.AccountDao;
import com.capgemini.javaparallelproject.dao.AccountDaoImpl;
import com.capgemini.javaparallelproject.exception.BankException;

public class AccountServiceImpl implements AccountService {

	static Map<Long, Account> map = new HashMap<>();
	AccountDao accountDao = new AccountDaoImpl();

	@Override
	public boolean validateName(String name) throws BankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean validateNumber(String mobileNo) throws BankException {
		boolean resultFlag = false;
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new BankException("first letter should be between 7-9 and the length should be 10");
		}
		return false;
	}

	@Override
	public boolean validateAmount(double amount) throws BankException {
		boolean amountFlag = false;

		if (amount < 500) {
			throw new BankException("amount should not be lessthan 500");
		} else {
			amountFlag = true;
		}
		return amountFlag;
	}

	@Override
	public long senderGenerateId() throws BankException {
				long accountNo =(long) (Math.random() * 100000000L); 
				return accountNo;
	}
	@Override
	public long receiverGenerateId() throws BankException {
				long accountNo =(long) (Math.random() * 100000000L); 
				return accountNo;
	}

	@Override
	public void addAccount(long accountNo, Account account) {
		accountDao.addAccount(accountNo,account);	
	}

	@Override
	public long deposit(long accNo, long amountDeposited) throws BankException {
		return accountDao.deposit(accNo, amountDeposited);
	}

	@Override
	public long withdrawl(long accountNo, long amountWithdrawl) throws BankException {
		return accountDao.withdrawl(accountNo, amountWithdrawl);
	}

	/*@Override
	public long addTransaction(long senderAccountNo, long recieverAccountNo, long transferAmount) throws BankException{
		return accountDao.transaction(senderAccountNo, recieverAccountNo, transferAmount);
	}*/

	@Override
	public long getBalance(long accountNo) {
		return accountDao.getBalance(accountNo);
	}

	@Override
	public int transacId() {
		int transactionId =(int) (Math.random() * 1000); 
		return transactionId;
	}

	
	@Override
	public boolean addTransaction(Transaction transaction) throws BankException {
		accountDao.addTraansaction(transaction);
		return true;
	}

	@Override
	public Set<Transaction> printTransaction()throws BankException{
		return accountDao.printTransaction();
	}

	@Override
	public Account checkAccountNo(long accountNo) throws BankException {
		return accountDao.checkaccountNo(accountNo);
	}

}
