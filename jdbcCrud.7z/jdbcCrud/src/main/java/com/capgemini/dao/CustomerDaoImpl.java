package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bean.Customer;
import com.capgemini.utility.DBConnection;

public class CustomerDaoImpl implements CustomerDao{

	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	boolean status=false;
	int row=-1;
	public int insertCustomer(Customer customer) {
		int custId=0;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select customerseq.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			if(resultSet.next())
				custId=resultSet.getInt(1);
			statement=connection.prepareStatement("insert into customer values(?,?,?,?,?)");
			statement.setInt(1, custId);
			statement.setString(2,customer.getName());
			statement.setString(3,customer.getAddress());
			Date sqldob=new Date(customer.getDob().getTime());
			statement.setDate(4, sqldob);
			statement.setLong(5, customer.getPhone());
			row=statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custId;
	}

	public int updateCustomer(Customer customer) {
		try(Connection connection=DBConnection.getConnection();) {
		statement=connection.prepareStatement("update customer set name=?,address=?,dob=?, phone=?, where custid=?");
		
		statement.setString(1,customer.getName());
		statement.setString(2,customer.getAddress());
		Date sqldob=new Date(customer.getDob().getTime());
		statement.setDate(3, sqldob);
		statement.setLong(4, customer.getPhone());
		statement.setInt(5, customer.getCustId());
		row=statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return row;
	}

	public int deleteCustomer(int custId) {
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("delete from customer where custid=?");
			
			statement.setInt(1,custId);
			
			row=statement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return row;
	}

	public Customer getByID(int custId) {
		Customer customer=null;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select * from customer where custid=?");
			statement.setInt(1,custId);
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				customer.setCustId(resultSet.getInt("custId"));
				customer.setName(resultSet.getString("name"));
				customer.setAddress(resultSet.getString("address"));
				customer.setDob(resultSet.getDate("dob"));
				customer.setPhone(resultSet.getLong("phone"));
			}
		}catch (SQLException e) {
				e.printStackTrace();
			}
		return customer;
	}
	
	public List<Customer> viewAll() {
		Customer customer=null;
		List<Customer> customerlist=new ArrayList<>();
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select * from customer");
			resultSet=statement.executeQuery();
			while(resultSet.next()) {
			customer=new Customer();
				customer.setCustId(resultSet.getInt("custId"));
				customer.setName(resultSet.getString("name"));
				customer.setAddress(resultSet.getString("address"));
				customer.setDob(resultSet.getDate("dob"));
				customer.setPhone(resultSet.getLong("phone"));
				customerlist.add(customer);
			}
		}catch (SQLException e) {
				e.printStackTrace();
			}
		return customerlist;
	}
	

}
