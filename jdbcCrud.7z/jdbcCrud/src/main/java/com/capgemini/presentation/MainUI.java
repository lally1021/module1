package com.capgemini.presentation;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.bean.Customer;
import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		CustomerService service=new CustomerServiceImpl();
		boolean status=false;
		while(true) {
			System.out.println("1.Register\n2.Update\n3.Delete\n4.ViewById\n5.ViewAll\n0.exit");
			int choice=scanner.nextInt();
			switch (choice) {
			case 0:System.exit(0);
			case 1:{
				try {
				System.out.println("Enter the name, address, phone");
				String name=scanner.next();
				String address=scanner.next();
				long phone=scanner.nextLong();
				System.out.println("Enter DOB format should be dd-MM-YYYY");
				String dob=scanner.next();
				SimpleDateFormat sf=new SimpleDateFormat("dd-MM-YYYY");
					Date d=sf.parse(dob);
				Customer customer=new Customer(0,name,address,d,phone);
				int custId=service.saveCustomer(customer);
				if(custId>0)
					System.out.println("Customer Registred successfully and your id is:"+custId);
				else
					System.out.println("Not Registered try again...");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}break;
			case 2: {
				try {
					System.out.println("enter custId to update");
					int custId=scanner.nextInt();
					System.out.println("Enter the name, address, phone");
					String name=scanner.next();
					String address=scanner.next();
					long phone=scanner.nextLong();
					System.out.println("Enter DOB format should be dd-MM-YYYY");
					String dob=scanner.next();
					SimpleDateFormat sf=new SimpleDateFormat("dd-MM-YYYY");
						Date d=sf.parse(dob);
					Customer customer=new Customer(0,name,address,d,phone);
					status=service.updateCustomer(customer);
					if(status)
						System.out.println("Customer Updated successfully");
					else
						System.out.println("Not updated try again...");
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
			}break;
			case 3: {
				try {
					System.out.println("enter custId to delete");
					int custId=scanner.nextInt();
					System.out.println("Enter the name, address, phone");
					String name=scanner.next();
					String address=scanner.next();
					long phone=scanner.nextLong();
					System.out.println("Enter DOB format should be dd-MM-YYYY");
					String dob=scanner.next();
					SimpleDateFormat sf=new SimpleDateFormat("dd-MM-YYYY");
						Date d=sf.parse(dob);
					Customer customer=new Customer(0,name,address,d,phone);
					status=service.updateCustomer(customer);
					if(status)
						System.out.println("Customer deleted successfully");
					else
						System.out.println("Not deleted try again...");
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}break;
			case 4:{
				System.out.println("enter custId to view");
				int custId=scanner.nextInt();
				Customer customer=service.viewById(custId);
				if(customer!=null)
					System.out.println(customer);
				else 
					System.out.println("Customer not found try again...");
			}break;
			case 5:{
				List<Customer> customerList = service.viewAll();
				System.out.println(customerList);
			}
		}
	}
	}
}

