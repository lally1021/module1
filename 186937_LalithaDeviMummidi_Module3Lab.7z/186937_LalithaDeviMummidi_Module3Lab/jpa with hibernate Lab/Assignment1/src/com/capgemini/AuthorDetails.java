package com.capgemini;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AuthorDetails {
	@Id
	@Column(name="AuthorId")
	private int AuthorId;
	private String fname;
	private String mname;
	private String lname;
	private String phone;
	public AuthorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AuthorDetails(int authorId, String fname, String mname, String lname, String phone) {
		super();
		AuthorId = authorId;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.phone = phone;
	}
	public int getAuthorId() {
		return AuthorId;
	}
	public void setAuthorId(int authorId) {
		AuthorId = authorId;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	

}
