package com.capgemini;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Update {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=factory.createEntityManager();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the id to be updated");
		int id=scan.nextInt();
		AuthorDetails auth=em.find(AuthorDetails.class, id);
		auth.setLname("lolly");
		auth.setAuthorId(9876);
		em.getTransaction().begin();
		em.persist(auth);
		em.getTransaction().commit();
		System.out.println("one row get updated");

	}

}
