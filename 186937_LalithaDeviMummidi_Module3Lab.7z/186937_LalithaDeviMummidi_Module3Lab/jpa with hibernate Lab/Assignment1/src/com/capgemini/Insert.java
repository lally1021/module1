package com.capgemini;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=factory.createEntityManager();
		AuthorDetails auth=new AuthorDetails(2341,"lilly","rosy","sanny","9878773421");
		em.getTransaction().begin();
		em.persist(auth);
		em.getTransaction().commit();
		System.out.println("one row get inserted");

		
	}

}
