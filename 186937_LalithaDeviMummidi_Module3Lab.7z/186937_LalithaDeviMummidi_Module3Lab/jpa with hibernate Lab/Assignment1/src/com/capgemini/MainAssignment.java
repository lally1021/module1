package com.capgemini;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager em=factory.createEntityManager();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the id to be deletd");
		int id=scan.nextInt();
		AuthorDetails auth=em.find(AuthorDetails.class, id);
		em.getTransaction().begin();
		em.remove(auth);
		em.getTransaction().commit();
		System.out.println("one row get deleted");



	}

}
