package com.capgemini;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class MainAss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		/*
		 * Scanner scan=new Scanner(System.in); System.out.println("enter author name");
		 * String authname=scan.nextLine();
		 */
		// em.getTransaction().begin();
		/* Author auth=em.find(Author.class, authname); */
		/*
		 * Book book=auth.getBook(); int num=book.getIsbn(); TypedQuery<Book> query=
		 * em.createNamedQuery("getAllBooks", Book.class); /* Query query1=
		 * em.createNamedQuery("getByName", Book.class); query1.setParameter(1,
		 * authname);
		 * 
		 * System.out.println(query1.getSingleResult());
		 */

		/*
		 * Query query=em.createQuery("from Book"); List<Book>
		 * auth=query.getResultList(); System.out.println(auth);
		 */
		
		
		/*
		 * Author auth1=new Author(); auth1.setName("Tagore"); Book b1=new Book();
		 * b1.setTitle("Ferrocious"); b1.setPrice(6000); b1.setAuthor(auth1); Book
		 * b2=new Book(); b2.setTitle("precious"); b2.setPrice(200);
		 * b2.setAuthor(auth1); auth1.getBook().add(b1); auth1.getBook().add(b2); Author
		 * auth2=new Author(); auth2.setName("Vikram"); Book b3=new Book();
		 * b3.setTitle("Music"); b3.setPrice(2000); b3.setAuthor(auth2); Book b4=new
		 * Book(); b4.setTitle("Tales"); b4.setPrice(300); b4.setAuthor(auth2);
		 * 
		 * auth2.getBook().add(b3); auth2.getBook().add(b4);
		 * 
		 * em.persist(auth1); em.persist(auth2); Author auth3=new Author();
		 * auth3.setName("Chaitu"); Book b5=new Book(); b5.setTitle("SavyaSachi");
		 * b5.setPrice(550); b5.setAuthor(auth3); Book b6=new Book();
		 * b6.setTitle("sensation"); b6.setPrice(670); b6.setAuthor(auth3);
		 * auth3.getBook().add(b5); auth3.getBook().add(b6);
		 * 
		 * em.persist(auth3);
		 */
		 
		 TypedQuery<Book> book= em.createQuery("from Book",Book.class);
		 List<Book> list1=book.getResultList();
		 for (Book book2 : list1) {
			System.out.println(book2);
		}
		
		
		  TypedQuery<Book> query1=em.createQuery("from Book where price>500 and price<1000", Book.class);
		  List<Book> list2=query1.getResultList();
		  System.out.println("books between given price range");
			 for (Book book2 : list2) {
				System.out.println(book2);
			}
			 
			 Scanner scan=new Scanner(System.in); System.out.println("enter author name");
			  String authname=scan.nextLine();
			
			  TypedQuery<Book> query = em.createQuery("select book from Author author join author.book book where author.name=?", Book.class); 
			  query.setParameter(1, authname);
			  List<Book> books =query.getResultList();
			  for (Book book1 : books)
			  {
				  System.out.println(book1);
				  }	  
			  System.out.println("Enter id");
		int id=scan.nextInt();
		TypedQuery<Author> q1=em.createQuery("select b.author from Book b where b.id=?", Author.class);
		q1.setParameter(1, id);
		List<Author> list22=q1.getResultList();
		for (Author author22 : list22) {
			System.out.println(author22);
		}
		  em.getTransaction().commit();
		 			
	}

}
