package com.cg;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mainc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("enter id:");
		int id=scan.nextInt();
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Employee emp=context.getBean("employee", Employee.class);
       emp.getInfo(id);
	}


	}


