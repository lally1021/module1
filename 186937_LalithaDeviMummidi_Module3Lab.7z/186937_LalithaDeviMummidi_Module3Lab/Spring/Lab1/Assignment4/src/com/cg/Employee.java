package com.cg;

import java.util.List;

public class Employee {
	private int employeeId;
	private String employeeName;
	private double salary;
	private List<Employee> emplist;
	public List<Employee> getEmplist() {
		return emplist;
	}
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary + "]";
	}
	public void getInfo(int id) {
		boolean status=false;
		
		for (Employee employee : emplist) {
			if(id==employee.getEmployeeId())
			{
				System.out.println("employee information is as follows :"+"\n"+"employeeId: "+employee.getEmployeeId()+"\n"+"employeeName:  "+employee.getEmployeeName()+"\n"+"employeeSalary: "+employee.getSalary());
	             status=true;
	             break;
			}
			
		}
		if(!status) {
			System.out.println("There is no employee with given id");
		}
	}

}
