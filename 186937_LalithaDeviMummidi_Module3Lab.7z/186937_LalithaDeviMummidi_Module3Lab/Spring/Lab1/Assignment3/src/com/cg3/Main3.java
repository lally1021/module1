package com.cg3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		SbuClass2 sb=context.getBean("sbuclass",SbuClass2.class);
		sb.getDetails();

	}

}
