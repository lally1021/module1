package com.cg3;

import java.util.List;

public class SbuClass2 {
	private int sbuId;
	private String sbuName;
	private String sbuHead;
	private List<Employee> emplist;
	public List<Employee> getEmplist() {
		return emplist;
	}
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	public int getSbuId() {
		return sbuId;
	}
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	

@Override
	public String toString() {
		return "SbuClass2 [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]";
	}
public void getDetails() {
	System.out.println("SbuClass2 [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]");
	System.out.println("employee under this category are");
	for (Employee employee : emplist) {
			/*
			 * System.out.println(employee.getEmployeeId());
			 * System.out.println(employee.getEmployeeName());
			 * System.out.println(employee.getSalary());
			 */
	System.out.println("EmployeeId is :"+employee.getEmployeeId()+"Employee Name is:"+employee.getEmployeeName()+"Employee Salary :"+employee.getSalary());;	
	}
		

}
}
