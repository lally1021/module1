package com.cg2;

public class Employee2 {


	private int employeeId;
	private String employeeName;
	private double salary;
	private int age;
	private String buUnit;
	private SbuClass sbuclass; 
	public SbuClass getSbuclass() {
		return sbuclass;
	}
	public void setSbuclass(SbuClass sbuclass) {
		this.sbuclass = sbuclass;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBuUnit() {
		return buUnit;
	}
	public void setBuUnit(String buUnit) {
		this.buUnit = buUnit;
	}
	public void getDetails() {
		System.out.println("employee Id is :"+employeeId);
		System.out.println("employee Name is:"+employeeName);
System.out.println("employee salary is :"+salary);
System.out.println("employee age is :"+age);
System.out.println("working unit is :"+buUnit);
System.out.print("sbu details are as follows: ");
System.out.println(" sbu id is:"+ sbuclass.getSbuId());
System.out.println("sbuName is:"+sbuclass.getSbuName());
System.out.println("sbu Head is "+sbuclass.getSbuHead());
	
	}
	

}

