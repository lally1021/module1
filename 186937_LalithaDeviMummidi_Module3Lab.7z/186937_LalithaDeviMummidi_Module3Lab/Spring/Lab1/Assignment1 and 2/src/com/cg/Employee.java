package com.cg;

public class Employee {
	
	
	private int employeeId;
	private String employeeName;
	private double salary;
	private int age;
	private String buUnit;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBuUnit() {
		return buUnit;
	}
	public void setBuUnit(String buUnit) {
		this.buUnit = buUnit;
	}
	public void getDetails() {
		System.out.println("employee Id is :"+employeeId);
		System.out.println("employee Name is:"+employeeName);
System.out.println("employee salary is :"+salary);
System.out.println("employee age is :"+age);
System.out.println("working unit is :"+buUnit);
	
	}
	

}
