package com.cg.course.service;

import java.util.List;

import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;

public interface CourseService {
	List<Course> getAllCourses() throws CourseException;
	List<Course> addCourse(Course course) throws CourseException;
	Course getById(String id) throws CourseException;
	List<Course> deleteById(String id) throws CourseException;
	List<Course> update(Course course,String id) throws CourseException;
	List<Course> getByCourse(String mode) throws CourseException;

}
