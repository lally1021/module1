package com.cg.course.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;

@Repository
public interface CourseDao extends JpaRepository<Course, String> {
	@Query("from Course where mode1=:mode")
List<Course> getByMode(@RequestParam String mode) throws CourseException;
}
