package com.cg.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;
import com.cg.course.service.CourseService;

@RestController
@RequestMapping("/course")
public class CourseController {
@Autowired	
	private CourseService service;

@PostMapping("/add")
public List<Course> addCourse(@RequestBody Course course) throws CourseException{
	return service.addCourse(course);
	
}
@GetMapping("/view")
public List<Course> getALl() throws CourseException{
	return service.getAllCourses();
}
@GetMapping("/view/{id}")
public Course getById(@PathVariable String id) throws CourseException{
	return service.getById(id);
	
}
@DeleteMapping("/delete/{id}")
public List<Course> delete(@PathVariable String id) throws CourseException{
return service.deleteById(id);	
}
@GetMapping("view/mode1")
public List<Course> getByMode(@RequestParam String mode1) throws CourseException{
	return service.getByCourse(mode1);
}
@PutMapping("/update/{id}")
public List<Course> updateById(@RequestBody Course course, @PathVariable String id) throws CourseException{
	return service.update(course, id);
}
@ExceptionHandler(CourseException.class)
public ResponseEntity<String> handleErrors(Exception ex){
	return new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
	
}

}
