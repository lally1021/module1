package com.cg.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.dao.CourseDao;
import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;

@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseDao dao;

	@Override
	public List<Course> getAllCourses() throws CourseException {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public List<Course> addCourse(Course course) throws CourseException {
		// TODO Auto-generated method stub
		
			if (course.getDuration() <3) {
				throw new CourseException(" duration must be greatr than 3");

			}
			if (course.getMode1().equalsIgnoreCase("online") || course.getMode1().equalsIgnoreCase("classroom")) {
				dao.save(course);
				return getAllCourses();
			} else {
				throw new CourseException("Mode must be either online or classroom only");
			}
		}

	@Override
	public Course getById(String id) throws CourseException {
		// TODO Auto-generated method stub
		if(dao.existsById(id))
		{
			return dao.findById(id).get();
		}
		else {
			throw new CourseException(" there is no such id present");
		}
	}

	@Override
	public List<Course> deleteById(String id) throws CourseException {
		// TODO Auto-generated method stub
		if(dao.existsById(id))
		{
			dao.deleteById(id);
			return getAllCourses();
		}
		else {
			throw new CourseException("there is no such id present");
		}
	}

	@Override
	public List<Course> update(Course course, String id) throws CourseException {
		// TODO Auto-generated method stub
		if(dao.existsById(id))
		{
			dao.save(course);
			return getAllCourses();
		}
		else {
			throw new CourseException("there is no such id present");
		}
		
	}

	@Override
	public List<Course> getByCourse(String mode) throws CourseException {
		// TODO Auto-generated method stub
		return dao.getByMode(mode);	
	}
}

