package com.cg.trainee.exception;

public class TraineeException extends Exception {

	public TraineeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TraineeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
