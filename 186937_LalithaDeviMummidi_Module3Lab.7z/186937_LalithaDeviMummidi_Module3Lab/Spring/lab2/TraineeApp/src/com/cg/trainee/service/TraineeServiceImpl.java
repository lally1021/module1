/**
 * 
 */
package com.cg.trainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.TraineeDao;
import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;
import com.cg.trainee.exception.TraineeException;

/**
 * @author pteegala
 *
 */
@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {
@Autowired
	TraineeDao dao;
	@Override
	public boolean ValidLogin(Login login) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.ValidLogin(login);
	}
	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		// TODO Auto-generated method stub
		return dao.getAllTrainees();
	}
	@Override
	public List<Trainee> addTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.addTrainee(trainee);
	}
	@Override
	public List<Trainee> deleteTrainee(int id) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(id);
	}
	@Override
	public Trainee getDetailsById(int id) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.getDetailsById(id);
	}
	@Override
	public List<Trainee> updateTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.updateTrainee(trainee);
	}

}
