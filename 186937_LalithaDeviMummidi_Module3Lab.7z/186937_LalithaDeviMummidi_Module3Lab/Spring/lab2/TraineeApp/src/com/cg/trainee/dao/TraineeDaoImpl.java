package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;
import com.cg.trainee.exception.TraineeException;
@Repository
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
EntityManager entitymanager;
	@Override
	public boolean ValidLogin(Login login) throws TraineeException {
		// TODO Auto-generated method stub
		boolean status=true;
		Login logins=entitymanager.find(Login.class, login.getId());
		if(logins==null)
		{
			status=false;
		}
		return status;
	}
	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		// TODO Auto-generated method stub
		   TypedQuery<Trainee> query=entitymanager.createQuery("from Trainee", Trainee.class);
		   List<Trainee> list1=query.getResultList();
		return list1;
	}
	@Override
	public List<Trainee> addTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		entitymanager.persist(trainee);
		return getAllTrainees();
	}
	@Override
	public List<Trainee> deleteTrainee(int id) throws TraineeException {
		// TODO Auto-generated method stub
		Trainee trainee=entitymanager.find(Trainee.class, id);
		if(trainee==null)
		{
			throw new TraineeException("there is no trainee present with that id");
		}
		entitymanager.remove(trainee);
		return getAllTrainees();
	}
	@Override
	public Trainee getDetailsById(int id) throws TraineeException {
		// TODO Auto-generated method stub
		Trainee traine=entitymanager.find(Trainee.class, id);
		return traine;
	}
	@Override
	public List<Trainee> updateTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		entitymanager.merge(trainee);
		return getAllTrainees();
	}

}
