package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface TraineeDao {
	boolean ValidLogin(Login login) throws TraineeException;
	List<Trainee> getAllTrainees() throws TraineeException;
	List<Trainee> addTrainee(Trainee trainee) throws TraineeException;
	List<Trainee> deleteTrainee(int id) throws TraineeException;
	Trainee getDetailsById(int id) throws TraineeException;
	List<Trainee> updateTrainee(Trainee trainee) throws TraineeException;

}
