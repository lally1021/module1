package com.cg.trainee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService service;
	
	@RequestMapping("/")
	public String viewLogin(Model model) {
		model.addAttribute("login", new Login());
		
		return "login";
	}
@RequestMapping(value="/login" ,method=RequestMethod.POST)
public ModelAndView showForm( @ModelAttribute Login login)
{
	try {
		boolean status=service.ValidLogin(login);
		if(status==true) {
			
			ModelAndView mv=new ModelAndView("index");
			return mv;
		}
		else {
			ModelAndView mv=new ModelAndView("login");
			return mv;
	
		}
		
	} catch (TraineeException e) {
		// TODO Auto-generated catch block
		ModelAndView mv=new ModelAndView("error");
		return mv;
	}
	
	
}
@RequestMapping("/retrieve")
public ModelAndView showAll() {
	try {
		List<Trainee> list=service.getAllTrainees();
		ModelAndView mv=new ModelAndView("show");
		mv.addObject("trainee", list);
		return mv;
	} catch (TraineeException e) {
		ModelAndView mv=new ModelAndView("error");
		mv.addObject("error", e);
		return mv;
		
			}
	
}
@RequestMapping("/add")
public String showAddForm(Model model) {
	model.addAttribute("trainee",new Trainee());
	return "add";
	
}
@RequestMapping(value="/addTrainee",method = RequestMethod.POST)
public ModelAndView addTrainee(@Valid @ModelAttribute Trainee trainee,BindingResult result)  {
	if(result.hasErrors()) {
		return new ModelAndView("add","trainee",trainee);
	}
	
	
	try {
		List<Trainee> trainees = service.addTrainee(trainee);
		ModelAndView mv=new ModelAndView("show");
		mv.addObject("trainee", trainees);
		return mv;

	} catch (TraineeException e) {
		ModelAndView mv=new ModelAndView("error");
		mv.addObject("error", e);
		return mv;
			}

}
@RequestMapping("/delete")
public String deleteForm()
{
	return "delete";
}
@RequestMapping(value="/deleteTrainee")
public ModelAndView deleteTrainee(@RequestParam int id) {
	try {
		List<Trainee> list1=service.deleteTrainee(id);
		ModelAndView mv=new ModelAndView("show");
		mv.addObject("trainee", list1);
		return mv;
	} catch (TraineeException e) {
		ModelAndView mv=new ModelAndView("error");
		mv.addObject("error", e);
		return mv;
		}
	
}

@RequestMapping("/update")
public String updateForm()
{
	return "update";
}

@RequestMapping(value="/updateTrainee")
public String showUpdateForm(@RequestParam int id,Model model) {
	
	try {
		Trainee trainees=service.getDetailsById(id);
		model.addAttribute("trainee",trainees);
		return "updateform";
	} catch (TraineeException e) {
      model.addAttribute("error", e);
      return "error";
	
	}

}

@RequestMapping(value="/updatingTrainee",method=RequestMethod.POST)
public ModelAndView UpdateEmployee(@Valid @ModelAttribute Trainee trainee,BindingResult result) {
	if(result.hasErrors()) {
		return new ModelAndView("updateform","trainee",trainee);
	}
	
	
	try {
		List<Trainee> traineess = service.updateTrainee(trainee);
		ModelAndView mv=new ModelAndView("show");
		mv.addObject("trainee", traineess);
		return mv;

	} catch (TraineeException e) {
		ModelAndView mv=new ModelAndView("error");
		mv.addObject("error", e);
		return mv;
			}

}

}
