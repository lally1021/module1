package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.ProductRepository;
import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository productrepository;

	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		return productrepository.findAll();
	}

	@Override
	public List<Product> addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		try {
			if (product.getQuantity() <= 0) {
				throw new ProductException("The value of quantity must be greater than 0");
			}
			if (product.getCategory().equalsIgnoreCase("TV") || product.getCategory().equalsIgnoreCase("mobile")
					|| product.getCategory().equalsIgnoreCase("laptop")) {
				productrepository.save(product);
				return getAllProducts();
			} else {
				throw new ProductException("product should be tv or laptop or mobile");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}

	}

	@Override
	public Product getProductById(int id) throws ProductException {
		// TODO Auto-generated method stub
		try {
			if (productrepository.existsById(id)) {
				return productrepository.findById(id).get();
			} else {
				throw new ProductException("there is no product with such id");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());

		}

	}

	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		try {
			if (productrepository.existsById(id)) {
				productrepository.deleteById(id);
				return getAllProducts();
			} else {
				throw new ProductException("there is no product with such id");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());

		}

	}

	@Override
	public List<Product> update(Product product, int id) throws ProductException {
				if(productrepository.existsById(id)) {
			Product prod=productrepository.findById(id).get();
			prod.setPrice(product.getPrice());
			prod.setQuantity(product.getQuantity());
			productrepository.save(prod);
			return getAllProducts();
			
		}
		else {
			throw new ProductException("Invalid Product");
		}
	}

	@Override
	public List<Product> getByCategory(String category) throws ProductException {
		// TODO Auto-generated method stub
		return productrepository.getProductByCategory(category);
	}

}
