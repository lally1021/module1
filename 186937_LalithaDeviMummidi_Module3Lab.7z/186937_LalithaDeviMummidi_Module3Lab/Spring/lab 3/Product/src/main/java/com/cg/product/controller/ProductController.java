package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;
import com.cg.product.service.ProductService;

@RestController 
@RequestMapping("/product")
public class ProductController {
@Autowired
	private ProductService service;
@GetMapping("/getAll")
public List<Product> getAllProducts() throws ProductException{
	 return service.getAllProducts();
}
@PostMapping("/add")
public List<Product> addProduct(@RequestBody Product product) throws ProductException{
	return service.addProduct(product);
	
}
@GetMapping("/view/{id}")
public Product getproduct(@PathVariable int id) throws ProductException {
	return service.getProductById(id);
}
@DeleteMapping("/delete/{id}")
public List<Product> delete(@PathVariable int id) throws ProductException {
	return service.deleteProduct(id);
	
}
@PutMapping("/Update/{id}")
public List<Product> update(@RequestBody Product product, @PathVariable int id) throws ProductException{
	return service.update(product,id);
}
@GetMapping("/view/Category")
public List<Product> getByCategory(@RequestParam String Category) throws ProductException{
	return service.getByCategory(Category);
}
@ExceptionHandler(ProductException.class)
public ResponseEntity<String> handle(Exception e){
	return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);

	
}
}
