package com.cg.product.exception;

public class ProductException extends Exception {

	public ProductException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
