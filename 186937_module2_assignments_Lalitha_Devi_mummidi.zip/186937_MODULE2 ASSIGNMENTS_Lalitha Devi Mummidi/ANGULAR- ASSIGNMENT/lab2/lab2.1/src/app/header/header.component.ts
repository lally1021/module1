import { Component, OnInit } from '@angular/core';

import data from '../../data/array.json';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  array=data
  constructor() { }

  ngOnInit() {
  }

  addnew(form){
    this.array.push({
      empId:form.empId,
      empName:form.empName,
      empSal:form.empSal,
      empDep:form.empDep
  });
  }
}
