import { Component, OnInit } from '@angular/core';
import data from '../../data/array.json';
import { UpdateService } from '../update.service';


@Component({
  selector: 'app-show-employees',
  templateUrl: './show-employees.component.html',
  styleUrls: ['./show-employees.component.css']
})
export class ShowEmployeesComponent implements OnInit {
array=data

  constructor(private uc: UpdateService) {
    
   }

  ngOnInit() {
  
  }
  delete(i)
  {
    data.splice(i,1)
  }
  
  public update(i:number)
  {
    this.uc.upsend(i);
  }

}
