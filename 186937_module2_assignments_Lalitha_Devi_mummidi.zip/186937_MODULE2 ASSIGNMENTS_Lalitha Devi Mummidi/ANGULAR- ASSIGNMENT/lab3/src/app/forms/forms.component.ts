import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  stores: Array<string>=[];
  
  print(form){
    console.log("Product Id:"+form.id)
    console.log("Product Name:"+form.name)
    console.log("Product Cost:"+form.cost)
    console.log("Product Online:"+form.online)
    console.log("Product Category:"+form.category)
    this.getstores(form)
    console.log("Available in stores:"+this.stores)
  }

  getstores(form){
    this.stores.splice(0,4)
    if(form.store1)
    {
      this.stores.push("Big Bazar")
    }
    if(form.store2)
    {
      this.stores.push("DMart")
    }
    if(form.store3)
    {
      this.stores.push("Reliance")
    }
    if(form.store4)
    {
      this.stores.push("Mega store")
    }
  }
}
