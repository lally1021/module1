package com.capgemini.jdbcparallelproject.service;

import java.util.List;
import java.util.Set;

import com.capgemini.jdbcparallelproject.bean.Account;
import com.capgemini.jdbcparallelproject.bean.Transaction;
import com.capgemini.jdbcparallelproject.exception.BankException;

public interface BankAccountService {

	public int saveAccount(long accountNo, Account account);
	long withdrawl(long accountNo, long amountWithdrawl);
	long deposit(long accountNo, long depositedAmount);
	long addAccount(long accountNo, Account account);
	boolean validateName(String name) throws BankException;
	boolean validateNumber(String mobileNo) throws BankException;
	boolean validateAmount(double amount) throws BankException;
	long generateId() throws BankException;
	public long getBalance(long accountNo);
	boolean addTransaction(Transaction transaction) throws BankException;
	int transacId();
	Set<Transaction> printTransaction() throws BankException;
	long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount);
	long addTransaction(long senderAccountNo, long recieverAccountNo, long transferAmount) throws BankException;
	
}
