package com.capgemini.jdbcparallelproject.service;

import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jdbcparallelproject.bean.Account;
import com.capgemini.jdbcparallelproject.bean.Transaction;
import com.capgemini.jdbcparallelproject.dao.BankAccountDao;
import com.capgemini.jdbcparallelproject.dao.BankAccountImpl;
import com.capgemini.jdbcparallelproject.exception.BankException;


public class BankAccountServiceImpl implements BankAccountService {
	boolean status=false;
	int row=-1;
	BankAccountDao accountDao = new BankAccountImpl();
	
	@Override
	public long generateId() throws BankException {
				long accountNo =(long) (Math.random() * 100000000L); 
				return accountNo;
	}
	
	@Override
	public long addAccount(long accountNo, Account account) {
	return accountDao.addAccount(accountNo, account);	
	}
	
	@Override
	public int saveAccount(long accountNo, Account account) {
		row=accountDao.addAccount(accountNo, account);
		return row;
	}
	
	@Override
	public long deposit(long accountNumber, long depositedAmount) {
		return accountDao.deposit(accountNumber,depositedAmount);
	}
	
		@Override
		public long withdrawl(long accountNo, long amountWithdrawl) {
			return accountDao.withdrawl(accountNo, amountWithdrawl);
		}

		@Override
		public long getBalance(long accountNo) {
			
			return accountDao.getBalance(accountNo);
		}

		@Override
		public int transacId() {
			int transactionId =(int) (Math.random() * 1000); 
			return transactionId;
		}
		
		@Override
		public boolean addTransaction(Transaction transaction) throws BankException {
			accountDao.addTransaction(transaction);
			return true;
		}
		
		@Override
		public Set<Transaction> printTransaction() throws BankException {
			return accountDao.printTransaction();
		}
				
		@Override
		public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount) {
			return accountDao.transaction(senderAccountNo, recieverAccountNo, transferAmount);
		}
		
		@Override
		public long addTransaction(long senderAccountNo, long recieverAccountNo, long transferAmount) throws BankException{
			return accountDao.transaction(senderAccountNo, recieverAccountNo, transferAmount);
		}
		
	@Override
	public boolean validateName(String name) throws BankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{2,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankException("first letter should be capital and length should be gt 2");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean validateNumber(String mobileNo) throws BankException {
		boolean resultFlag = false;
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new BankException("first letter should be between 7-9 and the length should be 10");
		}
		return false;
	}

	@Override
	public boolean validateAmount(double amount) throws BankException {
		boolean amountFlag = false;

		if (amount < 500) {
			throw new BankException("amount should not be lessthan 500");
		} else {
			amountFlag = true;
		}
		return amountFlag;
	}

}
