package com.capgemini.jdbcparallelproject.presentation;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.jdbcparallelproject.bean.Account;
import com.capgemini.jdbcparallelproject.bean.Transaction;
import com.capgemini.jdbcparallelproject.exception.BankException;
import com.capgemini.jdbcparallelproject.service.BankAccountService;
import com.capgemini.jdbcparallelproject.service.BankAccountServiceImpl;

public class Main {

	public static void main(String[] args) throws BankException {
		
		String continueChoice;
		boolean continueValue = false;
		Set<Transaction> st11=new LinkedHashSet<>();

		Scanner scanner = null;
		do {
			
			System.out.println("*** welcome to Banking***");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show Balance");
			System.out.println("6.Print Transactions");
			System.out.println("7.exit");
			
			BankAccountService service = new BankAccountServiceImpl();

			int choice = 0;
			boolean choiceFlag = false;
			
			do {
				
				
				System.out.println("Enter input:");
				
				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean flag = false;
					
					 //String recieverAccountNo="";
					 long balance=0;
					 long bal=0;
					 long amountDeposited=0;
					 long transferAmount=0;
					 long accountNo=0;
					 long accNo=0;
					 long amountWithdrawl=0;
					 //long balanceAfterDeposition=0;
                   
					switch (choice) {
					case 1:
					{
						 String firstName="";
						//String middleName="";
						//String lastName="";
						do {
						scanner = new Scanner(System.in);
						System.out.println("Enter First Name:");
						firstName=scanner.next();
						try {
							service.validateName(firstName);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						/*do {
							scanner = new Scanner(System.in);
						System.out.println("Enter Middle Name:");
						middleName=scanner.next();
						try {
							service.validateName(middleName);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter Last Name:");
						lastName=scanner.next();
						try {
							service.validateName(lastName);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						String name="";
						
						do {
							scanner = new Scanner(System.in);
						name=firstName.concat(middleName.concat(lastName));
						try {
							service.validateName(name);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);*/
						
						
						
						
						
						String mobileNo="";
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter mobile number:");
						mobileNo=scanner.next();
						try {
							service.validateNumber(mobileNo);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						
						
						String gender="";
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter Gender:");
						 gender=scanner.next();
						if(gender.equals("male")) {
							gender="Male";
							flag=true;
						}
						else if(gender.equals("female")) {
							gender="Female";
							flag=true;
						}
						else {
							System.out.println("gender should be in characters and it should be either male or female");
							flag=false;
						}
						}while (!flag);

						
						
						 balance=0;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							balance=scanner.nextLong();
							try {
								service.validateAmount(balance);
								flag = true;
							} catch (BankException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
							}while (!flag);
						
						accountNo = service.generateId();
						System.out.println("account created with the given id: " + accountNo);
						Account account = new Account(accountNo,balance,firstName,gender,mobileNo);
						service.saveAccount(accountNo,account);}
						break;
					
					case 2:
						
					{
						System.out.println("Enter account number:");
						scanner = new Scanner(System.in);
							accountNo=scanner.nextLong();
                        System.out.println("Enter amount to be deposited:");
                    scanner = new Scanner(System.in);
                     amountDeposited = scanner.nextLong();
                    LocalDate date = LocalDate.now();
							
                     long balanceAfterDeposit=service.deposit(accountNo, amountDeposited);
                     System.out.println( "final balance="+balanceAfterDeposit);
                     /*int transacId = service.transacId();
                     LocalDate date1 = LocalDate.now();
                     Transaction transaction = new Transaction(transacId, "deposit", date1, accountNo,balanceAfterDeposit);
                     
                     service.addTransaction(transaction);*/
                     
                    
                        }
                        break;
					
					case 3:{
						System.out.println("Enter account number to withdrawl:");
						scanner = new Scanner(System.in);
							accountNo=scanner.nextLong();
						System.out.println("Enter amount to be withdraw:");
	                    scanner = new Scanner(System.in);
	                     amountWithdrawl = scanner.nextLong();
	                    LocalDate date = LocalDate.now();
	                     long balanceAfterWithdrawl=service.withdrawl(accountNo, amountWithdrawl);
	                    
	                     System.out.println( "remaining balance="+balanceAfterWithdrawl);
	                     /*int transacId = service.transacId();
	                     LocalDate date1 = LocalDate.now();
	                     Transaction transaction = new Transaction(transacId, "withdrawl", date1, accountNo,balanceAfterWithdrawl);
	                     service.addTransaction(transaction);*/
					}
						break;
						
					/*case 4:{
						
							System.out.println("Enter sender's account number:");
							scanner = new Scanner(System.in);
								long senderAccountNo=scanner.nextLong();
  							
  							System.out.println("Enter reciever's account number:");
  							scanner = new Scanner(System.in);
  							long recieverAccountNo=scanner.nextLong();
                          
                          do {
    							
    							System.out.println("Enter amount to be transferred:");
    							scanner = new Scanner(System.in);
    							transferAmount=scanner.nextInt();
    							
    							try {
    								service.validateAmount(transferAmount);
    								flag = true;
    							} catch (BankException e) {
    								flag = false;
    								System.err.println(e.getMessage());
    							}
    							
    						}while(!flag);
                          long balanceAfterTransaction=service.addTransaction(senderAccountNo,recieverAccountNo,transferAmount);
                          System.out.println( "remaining balance="+balanceAfterTransaction);
                          int transacId = service.transacId();
                          LocalDate date1 = LocalDate.now();
                          Transaction transaction = new Transaction(transacId, "deposit", date1, accountNo,balanceAfterTransaction);
                          service.addTransaction(transaction);
					}
						break;*/
						
					case 5:
					{
								System.out.println("Enter your account number:");
								scanner = new Scanner(System.in);
									accountNo=scanner.nextLong();
									bal=service.getBalance(accountNo);
									  System.out.println("Your account balance is:"+bal);
					}
						break;
						
					case 6:
						 {
                                    System.out.println("your transactions are as mentioned:");
                                    scanner = new Scanner(System.in);
                                  System.out.println(service.printTransaction());
                                  
                                }
						break;
						
					case 7:
					
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
						
					default:
						
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
						
					}
				}catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
				
			}while(!choiceFlag);
			
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
			
		}while (continueValue);
		scanner.close();
	}

}
