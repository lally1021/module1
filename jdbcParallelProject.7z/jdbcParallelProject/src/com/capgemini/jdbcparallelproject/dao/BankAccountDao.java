package com.capgemini.jdbcparallelproject.dao;

import java.util.List;
import java.util.Set;

import com.capgemini.jdbcparallelproject.bean.Account;
import com.capgemini.jdbcparallelproject.bean.Transaction;
import com.capgemini.jdbcparallelproject.exception.BankException;

public interface BankAccountDao {

	public long getBalance(long accountNo);

	public int addAccount(long accountNo, Account account);

	public long deposit(long accountNumber, long depositedAmount);
	
	public long withdrawl(long accountNo, long amountWithdrawl);

	//public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount);

	public Set<Transaction> printTransaction() throws BankException;

	boolean addTransaction(Transaction transaction) throws BankException;

	public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount);

	public Account checkaccountNo(long accountNo) throws BankException;

}
