package com.capgemini.jdbcparallelproject.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.capgemini.jdbcparallelproject.bean.Account;
import com.capgemini.jdbcparallelproject.bean.Transaction;
import com.capgemini.jdbcparallelproject.exception.BankException;
import com.capgemini.jdbcparallelproject.utility.DBConnection;


public class BankAccountImpl implements BankAccountDao {
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	boolean status=false;
	int row=-1;
	static Map<Long, Account> map = new HashMap<>();
	static Set<Transaction> set = new LinkedHashSet<>();

	@Override
	public int addAccount(long accountNo, Account account) {
		int accNo=0;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select accountseq.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			
			if(resultSet.next()) {
			
			statement=connection.prepareStatement("insert into account values(?,?,?,?,?)");
			statement.setLong(1, account.getAccountNo());
			statement.setLong(2,account.getBalance());
			statement.setString(3,account.getName());
			statement.setString(4,account.getGender());
			statement.setString(5, account.getMobileNo());
			row=statement.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accNo;
	}
	
	public long deposit(long accountNumber, long depositedAmount) {
		long balance = 0;
		try(Connection connection=DBConnection.getConnection();) {
		statement=connection.prepareStatement("select balance from account where accountno=?");
		statement.setLong(1,accountNumber);
		ResultSet rs=statement.executeQuery();
        while(rs.next()) {
        	 balance=rs.getLong(1);
             statement=connection.prepareStatement("update account set balance=? where accountno=?");
			balance += depositedAmount ;
			
			statement.setLong(1,balance);
			statement.setLong(2,accountNumber);
		statement.executeUpdate();
        }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance;
	}
	
	public long withdrawl(long accountNo, long amountWithdrawl) {
		long balance = 0;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select balance from account where accountno=?");
			statement.setLong(1,accountNo);
			ResultSet rs=statement.executeQuery();
	        while(rs.next()) {
	        	  balance = rs.getLong(1);
	             statement=connection.prepareStatement("update account set balance=? where accountno=?");
				balance -= amountWithdrawl ;
				
				statement.setLong(1,balance);
				statement.setLong(2,accountNo);
			statement.executeUpdate();
	        }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance;
	}

	@Override
	public long getBalance(long accountNo) {
		long balance = 0;
		try(Connection connection=DBConnection.getConnection();) {
	    statement=connection.prepareStatement("select balance from account where accountno=?");
	    statement.setLong(1,accountNo);
		ResultSet rs=statement.executeQuery();
        while(rs.next()) {
        	 balance = rs.getLong(1);
        }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance;
	}
	
	@Override
	public boolean addTransaction(Transaction transaction) throws BankException {
		try(Connection connection=DBConnection.getConnection();){
			 statement=connection.prepareStatement("select transaction from account where accountno=?");
			    statement.set(1,accountNo);
			    ResultSet rs=statement.executeQuery();
		        while(rs.next()) {
		set.add(transaction);
		return true;
		}
	}
	}
	
	public Set<Transaction> printTransaction() throws BankException {
		return set;
	}

	@Override
	public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount) {
		return 0;
	}

	@Override
	public Account checkaccountNo(long accountNo) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	/*@Override
	public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount) {
		Iterator<Account> it1 = map.values().iterator();
		Long balance1 = 4567L;
		Long balance2 = 4567L;
		while (it1.hasNext()) {
			Account acc1 = it1.next();
			long acNo1 = acc1.getAccountNo();
			balance1 = acc1.getBalance();
			if (acNo1 == senderAccountNo) {
				while (it1.hasNext()) {
					Account acc2 = it1.next();
					long acNo2 = acc2.getAccountNo();
					balance2 = acc2.getBalance();
					if (acNo2 == recieverAccountNo) {
						balance2 = transferAmount + balance2;
						balance1 = balance1 - transferAmount;
						acc2.setBalance(balance2);
						acc1.setBalance(balance1);
					}
				}
			}
		}
		return balance1;
	}*/

	

}
