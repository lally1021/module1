package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Account {

	@Id
	@SequenceGenerator(name = "myseq", sequenceName="accoseq",allocationSize = 1)
    @GeneratedValue(strategy =GenerationType.SEQUENCE,generator = "myseq")
	  private long accountNo;
	private   String name;
	private String mobileNo;
	private  String aadharNo;
	private long accountBalance;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNo, String name, String mobileNo, String aadharNo, long accountBalance) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.mobileNo = mobileNo;
		this.aadharNo = aadharNo;
		this.accountBalance = accountBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public long getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(long accountBalance) {
		this.accountBalance = accountBalance;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", name=" + name + ", mobileNo=" + mobileNo + ", aadharNo="
				+ aadharNo + ", accountBalance=" + accountBalance + "]";
	}
	
	
}
