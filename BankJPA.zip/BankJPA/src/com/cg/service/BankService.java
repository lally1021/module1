package com.cg.service;

import com.cg.bean.Account;
import com.cg.exception.AccountException;

public interface BankService {

	long createAccount( Account account) throws AccountException;
	 boolean validateName(String name) throws AccountException;
	  boolean validateMobileNumber(String mobileNo) throws AccountException;
	  boolean validateAadharNumber(String aadharNo) throws AccountException;
	 // boolean validatePin(String pin) throws BankException;
	 // public long generateId() throws BankException;
	  public boolean validateAmount(long amount) throws AccountException;
	  boolean validateAccountNumber(long accNo) throws AccountException;
	 // public Account checkAccountNo(long accountNo)throws AccountException;
	long deposit(long accountNo, long amountDeposited) throws AccountException;
	public long transacId() throws AccountException;
	long withdrawl(long accountNo, long withdrawlAmount) throws AccountException;
	long transfer(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException;
	long showBalance(long accountNo) throws AccountException;
	  
}
