package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.Account;
import com.cg.dao.BankDao;
import com.cg.dao.BankDaoImpl;
import com.cg.exception.AccountException;

public class BankServiceImpl implements BankService {

	BankDao bdao=new BankDaoImpl();
	
	@Override
	public long createAccount(Account account) throws AccountException {
		// TODO Auto-generated method stub
		return bdao.saveAccount(account);
	}

	@Override
	public boolean validateName(String name) throws AccountException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new AccountException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean validateMobileNumber(String mobileNo) throws AccountException {
		
		boolean resultFlag = false;
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new AccountException("first letter should be between 7-9 and the length should be 10");
		}
		return false;
		
	}

	@Override
	public boolean validateAadharNumber(String aadharNo) throws AccountException {
		
		boolean resultFlag = false;
		String aadhar = String.valueOf(aadharNo);
		Pattern nameptn = Pattern.compile("^[0-9]{12}$");
		Matcher match = nameptn.matcher(aadhar);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new AccountException("aadhar number should contain 12 digits");
		}
		return false;
		
	}

	@Override
	public boolean validateAmount(long amount) throws AccountException {
		
		boolean amountFlag = false;

		if (amount < 500) {
			throw new AccountException("balance should not be lt 500");
		} else {
			amountFlag = true;
		}
		return amountFlag;
	}
		
	@Override
	public boolean validateAccountNumber(long accNo) throws AccountException
	{
		boolean resultFlag=false;
		String accountNo=String.valueOf(accNo); 
		Pattern nameptn = Pattern.compile("^[0-9]{10}$");
		Matcher match = nameptn.matcher(accountNo);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new AccountException("account number should contain 10 digits");
		}
		return false;
	}

//	@Override
//	public Account checkAccountNo(long accountNo) throws AccountException {
//		// TODO Auto-generated method stub
//		return bdao.checkAccountNo(accountNo);
//	}

	@Override
	public long deposit(long accountNo, long amountDeposited) throws AccountException {
		// TODO Auto-generated method stub
		return bdao.deposit(accountNo,amountDeposited);
	}

	@Override
	public long transacId() throws AccountException {
		
		long accountNo =(long) (Math.random() * 100000000L); 
		return accountNo;
		
	}

	@Override
	public long withdrawl(long accountNo, long withdrawlAmount) throws AccountException {
		
		return bdao.withdrawl(accountNo,withdrawlAmount);
		
	}

	@Override
	public long transfer(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException {
		return bdao.transfer(senderAccountNo,recieverAccountNo,transferAmount);
	}

	@Override
	public long showBalance(long accountNo) throws AccountException {
		// TODO Auto-generated method stub
		return bdao.showBalance(accountNo);
	}

}
