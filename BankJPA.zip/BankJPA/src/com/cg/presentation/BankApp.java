package com.cg.presentation;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.exception.AccountException;
import com.cg.service.BankService;
import com.cg.service.BankServiceImpl;

public class BankApp {

	public static void main(String[] args) throws AccountException {
		String continueChoice;
		boolean continueValue = false;
		Scanner scanner = null;
		do {

			System.out.println("*** welcome to XYZ Bank***");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show Balance");
			System.out.println("6.exit");
			int choice = 0;
			boolean choiceFlag = false;

			BankService service = new BankServiceImpl();
			do {

				scanner = new Scanner(System.in);
				System.out.println("Enter input:");

				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean flag = false;
					long accountNo, balance, amountDeposited, accountBalance, withdrawlAmount, senderAccountNo,
							recieverAccountNo, transferAmount;
					String name, firstName, lastName, mobileNo, aadharNo, pin, proceed;

					switch (choice) {

					case 1: {

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter First Name:");
							firstName = scanner.next();
							try {
								service.validateName(firstName);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Last Name:");
							lastName = scanner.next();
							try {
								service.validateName(lastName);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							name = firstName.concat(lastName);
							try {
								service.validateName(name);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile number:");
							mobileNo = scanner.next();
							try {
								service.validateMobileNumber(mobileNo);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							balance = scanner.nextLong();
							try {
								service.validateAmount(balance);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter aadhar number:");
							aadharNo = scanner.next();
							try {
								service.validateAadharNumber(aadharNo);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);
						// System.out.println("gjhfgsjh");

						Account account = new Account(0, name, mobileNo, aadharNo, balance);
						long number = service.createAccount(account);
						System.out.println("Account number is " + number);
						// if(created) {
						// System.out.println("Account created successfully " + accountNo);
						// }
						// else {
						// System.out.println("Account creation failed.....Try Again...");
						// }
					}
						break;
					case 2: {
						System.out.println("enter account Number");
						accountNo = scanner.nextLong();
						// accountFlag=true;

						System.out.println("enter amount to deposit");
						amountDeposited = scanner.nextLong();
						long deposit = service.deposit(accountNo, amountDeposited);
						System.out.println(deposit);

					}
						break;

					case 3: {
						System.out.println("enter account Number");
						accountNo = scanner.nextLong();
						// accountFlag=true;

						System.out.println("enter amount for withdrawl");
						withdrawlAmount = scanner.nextLong();
						long withdrawl = service.withdrawl(accountNo, withdrawlAmount);
						System.out.println(withdrawl);

					}
						break;
					case 4: {
						System.out.println("enter sender account Number");
						senderAccountNo = scanner.nextLong();
						// accountFlag=true;

						System.out.println("enter receiver account Number");
						recieverAccountNo = scanner.nextLong();

						System.out.println("enter amount for transfer");
						transferAmount = scanner.nextLong();
						long transfer = service.transfer(senderAccountNo, recieverAccountNo, transferAmount);
						System.out.println(transfer);
					}
						break;
					case 5: {
						System.out.println("Enter Account Number");
						accountNo = scanner.nextLong();
						accountBalance = service.showBalance(accountNo);

						System.out.println("Account Balance :" + accountBalance);

					}
						break;
					case 6:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;

					default:
						System.out.println("input should be 1,2,3,4,5 or 6");
						choiceFlag = false;
						break;
					}
				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}

			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
	}

}
