package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.bean.Account;
import com.cg.exception.AccountException;

public class BankDaoImpl implements BankDao {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
    EntityManager em=emf.createEntityManager();
    TypedQuery<Account> tq;
    long accBal;
	
	@Override
	public long saveAccount(Account a) throws AccountException {
		
		em.getTransaction().begin();
		em.persist(a);
		em.getTransaction().commit();
			return a.getAccountNo();
		
	}

	@Override
	public long deposit(long accountNo, long amountDeposited) throws AccountException {
		
		long balance = 0;
		em.getTransaction().begin();

		Account acc = em.find(Account.class, accountNo);
		balance = (long) acc.getAccountBalance();
		acc.setAccountBalance(balance + amountDeposited);

		em.getTransaction().commit();
		return balance + amountDeposited;
		
	}

	@Override
	public long withdrawl(long accountNo, long withdrawlAmount) throws AccountException {
		
		long balance = 0;
		em.getTransaction().begin();

		Account acc = em.find(Account.class, accountNo);
		balance = (long) acc.getAccountBalance();
		acc.setAccountBalance(balance - withdrawlAmount);

		em.getTransaction().commit();
		return balance - withdrawlAmount;
		
	}

	@Override
	public long transfer(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException {

		long senderBalance,recieverBalance;
		em.getTransaction().begin();

		Account senderAcc = em.find(Account.class, senderAccountNo);
		senderBalance = (long) senderAcc.getAccountBalance();
		Account recieverAcc = em.find(Account.class, recieverAccountNo);
		recieverBalance = (long) senderAcc.getAccountBalance();
		recieverAcc.setAccountBalance(recieverBalance + transferAmount);
		senderAcc.setAccountBalance(senderBalance - transferAmount);

		em.getTransaction().commit();
		return senderBalance - transferAmount;
	}

	@Override
	public long showBalance(long accountNo) throws AccountException {
		long balance=0;
		 em.getTransaction().begin();
		 Account senderAcc = em.find(Account.class, accountNo);
			balance = (long) senderAcc.getAccountBalance();
			return balance;
//		   tq = em.createQuery("select acc from Account acc where acc.accountNo= :acNo and acc.pin= :p", Account.class);
//	       tq.setParameter("acNo", accountNo);
//	       tq.setParameter("p", pin);
//		   Account a= tq.getSingleResult();
//		   em.getTransaction().commit();
//		   if(a!=null)
//			   return a.getAccountBalance();
//			return -1;
	}

	

	
}
