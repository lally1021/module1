package com.cg.dao;

import com.cg.bean.Account;
import com.cg.exception.AccountException;

public interface BankDao {

	long saveAccount(Account a) throws AccountException;
	//public Account checkAccountNo(long accountNo) throws AccountException;
	long deposit(long accountNo, long amountDeposited) throws AccountException;
	long withdrawl(long accountNo, long withdrawlAmount) throws AccountException;
	long transfer(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException;
	long showBalance(long accountNo) throws AccountException;
}
