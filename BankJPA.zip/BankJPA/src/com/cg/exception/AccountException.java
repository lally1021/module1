package com.cg.exception;

public class AccountException extends Exception{

	public AccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
	
}
